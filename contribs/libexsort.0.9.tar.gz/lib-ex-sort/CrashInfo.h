#ifndef __CRASH_INFO_H
void SetUpCrashRecovery();
#endif
